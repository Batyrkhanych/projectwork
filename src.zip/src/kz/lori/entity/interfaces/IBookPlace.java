package kz.lori.entity.interfaces;

public interface IBookPlace {
	public int getId();
	public int getPersonid();
	
}
