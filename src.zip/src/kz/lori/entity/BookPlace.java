package kz.lori.entity;

import kz.lori.entity.interfaces.IBookPlace;

public class BookPlace implements IBookPlace {
	private int id;
	private int stage;
	private boolean free;
	private int personid;
	public BookPlace(int id, int stage, boolean free, int personid) {
		super();
		this.id = id;
		this.stage = stage;
		this.free = free;
		this.personid = personid;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the stage
	 */
	public int getStage() {
		return stage;
	}
	/**
	 * @param stage the stage to set
	 */
	public void setStage(int stage) {
		this.stage = stage;
	}
	/**
	 * @return the free
	 */
	public boolean isFree() {
		return free;
	}
	/**
	 * @param free the free to set
	 */
	public void setFree(boolean free) {
		this.free = free;
	}
	/**
	 * @return the personid
	 */
	public int getPersonid() {
		return personid;
	}
	/**
	 * @param personid the personid to set
	 */
	public void setPersonid(int personid) {
		this.personid = personid;
	}
	@Override
	public String toString() {
		return "BookPlace [id=" + id + ", stage=" + stage + ", free=" + free + ", personid=" + personid + "]";
	}
	
}
