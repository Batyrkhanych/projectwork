package kz.lori.entity;

public class Person {
	private int id;
	private String name;
	private String telephone;
	private String address;
	private int carid;
	public Person(int id, String name, String telephone, String address, int carid) {
		super();
		this.id = id;
		this.name = name;
		this.telephone = telephone;
		this.address = address;
		this.carid = carid;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the telephone
	 */
	public String getTelephone() {
		return telephone;
	}
	/**
	 * @param telephone the telephone to set
	 */
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the carid
	 */
	public int getCarid() {
		return carid;
	}
	/**
	 * @param carid the carid to set
	 */
	public void setCarid(int carid) {
		this.carid = carid;
	}
	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", telephone=" + telephone + ", address=" + address + ", carid="
				+ carid + "]";
	}
	
}
