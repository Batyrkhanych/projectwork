package kz.lori;

import java.util.List;
import java.util.Random;
import java.util.Scanner;

import kz.lori.controllers.BookPlaceController;
import kz.lori.entity.BookPlace;
import kz.lori.entity.Person;
import kz.lori.entity.interfaces.IBookPlace;

public class Application {
	public void start(Scanner scanner, BookPlaceController controller) {
		int choose;
		while(true) {
		System.out.println("Hello, our respondend"
				+ "\n 1 - register person"
				+ "\n 2 - print all places "
				+ "\n 3 - register place for person");
		choose = scanner.nextInt();
		switch(choose) {
		case 1:
			this.register(scanner, controller);
			break;
		case 2:
			this.printAllPlaces(scanner, controller);
			break;
		case 3:
			this.registerPlace(scanner, controller);
			break;
		default:
			System.out.println("Exit...");
			return;
		}
		}
	}
	public void register(Scanner scanner, BookPlaceController controller) {
		System.out.println("This is register menu");
		System.out.println("Write your id");
		int id = scanner.nextInt();
		System.out.println("Write your name");
		String name = scanner.next();
		System.out.println("Write your telephone number");
		String telephone = scanner.next();
		System.out.println("Write your address");
		String address = scanner.next();
		System.out.println("Write your car id");
		int carid = scanner.nextInt();
		Person person = new Person(id, name, telephone, address, carid);
		controller.addPerson(person);
		System.out.println(person.toString());
	}
	public void printAllPlaces(Scanner scanner, BookPlaceController controller) {
		List<IBookPlace> places = controller.getAllPlaces();
		for(int i = 0; i < places.size(); i++) {
			System.out.println(places.get(i).toString());
		}
	}
	public void registerPlace(Scanner scanner, BookPlaceController controller) {
		System.out.println("Write please your id and stage");
		int id = scanner.nextInt();
		int stage = scanner.nextInt();
		BookPlace place = new BookPlace(new Random().nextInt(99999), stage, false, id);
		controller.addBookPlace(place);
		System.out.println(place.toString() + " has been added");
	}
 }
