package kz.lori;

import java.util.List;
import java.util.Scanner;

import org.postgresql.jdbc2.optional.PoolingDataSource;

import com.company.data.PostgresDB;
import com.company.data.interfaces.IDB;

import kz.lori.controllers.BookPlaceController;
import kz.lori.entity.interfaces.IBookPlace;

public class Main {
	public static void main(String[] args) {
		IDB idb = new PostgresDB();
		BookPlaceController controller = new BookPlaceController(idb);
		Scanner scanner = new Scanner(System.in);
		Application app = new Application();
		app.start(scanner, controller);
		 
	}
}
